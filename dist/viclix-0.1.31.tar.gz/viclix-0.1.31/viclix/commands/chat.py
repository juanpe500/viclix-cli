"""Interactive full-terminal chat for `viclix agents` — a Textual TUI over the
headless coding-agent (Phase A).

Flow (token API only, no server change):
  • pick or start a session
  • type a prompt → POST /api/v1/projects/agent/runs {goal, mode, session_id}
  • stream the run by polling GET .../agent/runs/{run_id}?since=<maxIdx>
  • render each step kind; tool calls/results are CLICKABLE collapsibles
  • Esc cancels the running turn; Ctrl+Q quits

Model selection (/model) is Phase B — for now the run uses the account's default
model (shown in the footer) and /model opens the dashboard provider page.

Textual is imported lazily by `launch()` so the rest of the CLI never depends on
it; a missing install degrades to a friendly message.
"""
import json
import time
import webbrowser

import requests

from ..console import logger
from ..api import require_auth, _tok_url, _dashboard_base, reconcile_project_data

# Statuses at which a run is finished and polling stops.
TERMINAL = {"done", "error", "cancelled", "chat", "needs_input"}
MODES = ["plan", "manual", "auto_edit", "full"]
MODE_HELP = {
    "plan": "read-only — explores & answers, never edits/deploys",
    "manual": "builds; every edit & exec waits for your approval",
    "auto_edit": "builds; edits auto-apply, execs still gated",
    "full": "builds; auto-approves all but redeploy/run-agent/delete-agent",
}


def _esc(s):
    """Escape Textual markup in dynamic text — agent output, tool results, code
    and titles routinely contain '[' / '[/]' which the markup parser would try to
    interpret as tags (raising MarkupError). Our own literal tags are added around
    already-escaped content, so they still render."""
    return str(s or "").replace("[", r"\[")


def _fmtk(n):
    """Compact token count: 7098 → '7k', 371000 → '371k', 1200000 → '1.2M'."""
    try:
        n = int(n)
    except (TypeError, ValueError):
        return "0"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1000:
        return f"{n / 1000:.0f}k"
    return str(n)


def _tok_tag(step):
    """Dim '· <in> in · <out> out' suffix for a step that reports token usage."""
    i = step.get("input_tokens") or 0
    o = step.get("output_tokens") or 0
    if i or o:
        return f"   [dim]· {_fmtk(i)} in · {_fmtk(o)} out[/]"
    return ""


def cmd_agents_chat(args, cfg):
    """Entry point: launch the interactive chat, or explain if textual is missing."""
    base_url = cfg["base_url"]
    # Upgrade an old-format .viclix (backfills project_id from the api_key, etc.).
    proj = reconcile_project_data(base_url, args)
    token, project_id = require_auth(args, proj or {})
    # project_id may be None when using a project api_key — the token
    # self-identifies the project, so that's fine.
    try:
        app = _build_app(base_url, token, project_id)
    except ModuleNotFoundError:
        logger.error("The interactive chat needs the 'textual' package. Install it with:\n"
                     "    pip install --upgrade textual\n"
                     "or view conversations read-only with:  viclix agents --json")
        return
    app.run()


def _build_app(base_url, token, project_id):
    """Construct the Textual app. Imports live here so importing this module (and
    the CLI as a whole) never requires textual until the chat is actually used."""
    from textual.app import App, ComposeResult
    from textual.screen import Screen, ModalScreen
    from textual.containers import VerticalScroll, Vertical
    from textual.suggester import SuggestFromList
    from textual.widgets import (
        Header, Footer, Input, Static, Label, ListView, ListItem, Collapsible,
    )

    # Slash-command autocomplete (inline ghost text; → or Tab accepts).
    slash_suggester = SuggestFromList(
        ["/help", "/model", "/usage", "/new", "/sessions", "/quit",
         "/mode plan", "/mode manual", "/mode auto_edit", "/mode full"],
        case_sensitive=False,
    )

    dash = _dashboard_base(base_url)

    # ── small render helpers (return a widget for one agent step) ────────────
    def _summarize(kind, tool, content):
        """One-line, markup-safe title for a collapsible tool card."""
        c = (content or "").strip().replace("\n", " ")
        if kind == "tool_call":
            try:
                targs = json.loads(content)
                bits = []
                for k in ("path", "command", "url", "name"):
                    if k in targs:
                        bits.append(str(targs[k]))
                summary = "  ".join(bits) or c[:80]
            except Exception:
                summary = c[:80]
            return _esc(f"→ {tool or 'tool'}  {summary}")
        if kind == "tool_result":
            return _esc(f"← {tool or 'result'}  {c[:80]}")
        return _esc(c[:100])

    def step_widget(step):
        kind = step.get("kind")
        tool = step.get("tool") or step.get("tool_name")
        content = step.get("content") or ""
        if kind == "llm":
            return Static(f"[dim italic]{_esc(content.strip())}[/]{_tok_tag(step)}", classes="think")
        if kind == "reply":
            return Static(_esc(content.strip()), classes="reply")
        if kind == "status":
            return Static(f"[dim]· {_esc(content.strip())}[/]", classes="status")
        if kind == "error":
            return Static(f"[b red]error[/] {_esc(content.strip())}", classes="error")
        if kind in ("tool_call", "tool_result"):
            body = content
            if kind == "tool_call":
                try:
                    body = json.dumps(json.loads(content), indent=2)
                except Exception:
                    body = content
            col = Collapsible(Static(_esc(body)), title=_summarize(kind, tool, content),
                              collapsed=True, classes="tool")
            return col
        if kind == "ask":
            try:
                q = json.loads(content)
                txt = q.get("question", content)
                opts = q.get("options") or []
                extra = ("\n  " + "  ".join(f"\\[{i+1}] {_esc(o)}" for i, o in enumerate(opts))) if opts else ""
                return Static(f"[b yellow]? {_esc(txt)}[/]{extra}\n[dim](type your answer as the next message)[/]",
                              classes="ask")
            except Exception:
                return Static(f"[b yellow]? {_esc(content)}[/]", classes="ask")
        if kind == "approval":
            try:
                a = json.loads(content)
                return Static(f"[b magenta]approval needed[/] for [b]{_esc(a.get('tool'))}[/] "
                              f"[dim](interactive approvals land in a later version — "
                              f"use mode 'full' or approve in the dashboard)[/]", classes="ask")
            except Exception:
                return Static(f"[b magenta]approval needed[/] {_esc(content)}", classes="ask")
        # ui_action / browser_test / restart_needed / approval_result / others
        return Static(f"[dim]· {_esc(kind)}: {_esc(content.strip()[:120])}[/]", classes="status")

    # ── session picker screen ────────────────────────────────────────────────
    class SessionPicker(Screen):
        BINDINGS = [("ctrl+q", "app.quit", "Quit"), ("r", "refresh", "Refresh")]

        def compose(self) -> ComposeResult:
            yield Header(show_clock=False)
            yield Label("Your AI conversations — pick one to continue, or start a new chat:",
                        classes="hint")
            yield ListView(id="sessions")
            yield Footer()

        def on_mount(self):
            self.load()

        def action_refresh(self):
            self.load()

        def load(self):
            self._load_worker()

        def _load_worker(self):
            def go():
                try:
                    r = requests.get(_tok_url(base_url, "projects/agent/sessions", token, project_id),
                                     timeout=20)
                    sessions = (r.json() or {}).get("sessions", []) if r.status_code == 200 else []
                except requests.RequestException:
                    sessions = []
                self.app.call_from_thread(self._fill, sessions)
            self.run_worker(go, thread=True, exclusive=True)

        def _fill(self, sessions):
            lv = self.query_one("#sessions", ListView)
            lv.clear()
            lv.append(ListItem(Label("＋  New chat"), id="new"))
            for s in sessions:
                when = (s.get("updated_at") or "")[:16].replace("T", " ")
                title = (s.get("title") or "(untitled)").replace("\n", " ")[:70]
                item = ListItem(Label(f"{_esc(title)}\n[dim]{when}[/]"))
                item.session_id = s.get("id")
                lv.append(item)
            lv.focus()

        def on_list_view_selected(self, event):
            item = event.item
            sid = None if item.id == "new" else getattr(item, "session_id", None)
            self.app.open_chat(sid)

    # ── model picker (modal): favorites list + "open selector" as the last item ─
    class ModelPicker(ModalScreen):
        BINDINGS = [("escape", "dismiss", "Close")]

        def __init__(self, favorites, current):
            super().__init__()
            self.favorites = favorites or []
            self.current = current

        def compose(self) -> ComposeResult:
            items = []
            for f in self.favorites:
                if isinstance(f, dict):
                    mid = f.get("id") or ""
                    name = f.get("name") or mid
                    meta = []
                    ctx = f.get("context_length")
                    if ctx:
                        try:
                            meta.append(f"{int(ctx) // 1000}k ctx")
                        except (TypeError, ValueError):
                            pass
                    pin, pout = f.get("price_in_per_m"), f.get("price_out_per_m")
                    if pin is not None or pout is not None:
                        meta.append(f"${pin if pin is not None else '?'}/${pout if pout is not None else '?'} per M")
                    tail = ("   [dim]" + _esc(" · ".join(meta)) + "[/]") if meta else ""
                    label = f"{_esc(name)}   [dim]{_esc(mid)}[/]{tail}"
                else:
                    mid = str(f)
                    label = _esc(mid)
                mark = "● " if mid == self.current else "  "
                li = ListItem(Label(f"{mark}{label}"))
                li.model_id = mid
                li.is_open = False
                items.append(li)
            openitem = ListItem(Label("🌐  Open model selector in browser…"))
            openitem.model_id = None
            openitem.is_open = True
            items.append(openitem)
            yield Vertical(
                Label("[b]Choose a model[/]   [dim](↑↓ Enter · Esc to close)[/]"),
                ListView(*items, id="models"),
                id="picker",
            )

        def on_mount(self):
            self.query_one("#models", ListView).focus()

        def on_list_view_selected(self, event):
            item = event.item
            if getattr(item, "is_open", False):
                try:
                    webbrowser.open(f"{dash}/settings/ai-providers")
                except Exception:
                    pass
                self.dismiss(None)
            else:
                self.dismiss(getattr(item, "model_id", None))

    # ── reasoning-effort picker (modal): shown when a reasoning model is chosen ──
    class ReasoningPicker(ModalScreen):
        BINDINGS = [("escape", "dismiss", "Close")]

        def __init__(self, model_id, efforts, mandatory, current):
            super().__init__()
            self.model_id = model_id
            self.efforts = efforts or []
            self.mandatory = mandatory
            self.current = current

        def compose(self) -> ComposeResult:
            order = ["minimal", "low", "medium", "high", "xhigh"]
            ordered = [e for e in order if e in self.efforts]
            ordered += [e for e in self.efforts if e not in order]
            if not self.mandatory:
                ordered.append("none")   # allow turning reasoning off
            items = []
            for e in ordered:
                mark = "● " if e == self.current else "  "
                li = ListItem(Label(f"{mark}{_esc(e)}"))
                li.effort = e
                items.append(li)
            yield Vertical(
                Label(f"[b]Reasoning effort[/]   [dim]{_esc(self.model_id)}[/]"),
                ListView(*items, id="efforts"),
                id="reasonbox",
            )

        def on_mount(self):
            self.query_one("#efforts", ListView).focus()

        def on_list_view_selected(self, event):
            self.dismiss(getattr(event.item, "effort", None))

    # ── usage panel (modal): context window + spend by model + total ────────────
    class UsageModal(ModalScreen):
        BINDINGS = [("escape", "dismiss", "Close"), ("u", "dismiss", "Close")]

        def compose(self) -> ComposeResult:
            a = self.app
            lines = ["[b]CONTEXT WINDOW[/]"]
            cmax = a.ctx_max_by_model.get(a.model)
            if cmax:
                pct = (a.ctx_used / cmax * 100) if cmax else 0
                lines.append(f"  {_fmtk(a.ctx_used)} / {_fmtk(cmax)} tok      [green]{pct:.1f}%[/]")
            else:
                lines.append(f"  {_fmtk(a.ctx_used)} tok in context   "
                             f"[dim](max unknown — favorite the model to see %)[/]")
            lines.append("")
            lines.append("[b]SPENT BY MODEL[/]")
            if not a.usage_by_model:
                lines.append("  [dim]no runs yet this session[/]")
            for model, u in a.usage_by_model.items():
                lines.append(f"  {_esc(model)}   [dim]{u['msgs']} msg[/]   "
                             f"[cyan]{_fmtk(u['in'])} ↑[/] [yellow]{_fmtk(u['out'])} ↓[/]   "
                             f"[green]${u['cost']:.4f}[/]")
            total_msgs = sum(u["msgs"] for u in a.usage_by_model.values())
            lines.append("")
            lines.append(f"[b]Total[/]   [dim]{total_msgs} msg[/]   "
                         f"[cyan]{_fmtk(a.tok_in)} ↑[/] [yellow]{_fmtk(a.tok_out)} ↓[/]   "
                         f"[green]${a.cost:.4f}[/]")
            yield Vertical(
                Static("\n".join(lines)),
                Label("[dim]Esc to close[/]"),
                id="usagebox",
            )

    # ── chat screen ───────────────────────────────────────────────────────────
    class ChatScreen(Screen):
        BINDINGS = [
            ("ctrl+q", "app.quit", "Quit"),
            ("escape", "cancel", "Cancel turn"),
            ("ctrl+n", "sessions", "Sessions"),
        ]

        def __init__(self, session_id):
            super().__init__()
            self.session_id = session_id
            self.run_id = None
            self.busy = False

        def compose(self) -> ComposeResult:
            yield Header(show_clock=False)
            yield Static("[dim]▸ your last message will pin here[/]", id="lastmsg")
            yield VerticalScroll(id="log")
            yield Input(placeholder="Type a message…  (/ for commands)", id="prompt",
                        suggester=slash_suggester)
            yield Static(self._status_text(), id="status")
            yield Footer()

        def _set_last(self, text):
            """Pin the user's most recent message at the top so it's always visible."""
            t = " ".join((text or "").split())
            self.query_one("#lastmsg", Static).update(f"[b green]▸ you asked:[/] {_esc(t)}")

        def _status_text(self):
            a = self.app
            cmax = a.ctx_max_by_model.get(a.model)
            if cmax:
                pct = (a.ctx_used / cmax * 100) if cmax else 0
                ctx = f"{_fmtk(a.ctx_used)}/{_fmtk(cmax)} ({pct:.0f}%)"
            else:
                ctx = _fmtk(a.ctx_used)
            reason = f" [magenta]R:{_esc(a.reasoning_effort)}[/]" if a.reasoning_effort else ""
            return (f"[b]{_esc(a.model)}[/] [dim]· {a.mode}[/]{reason}   "
                    f"[dim]ctx[/] {ctx}   "
                    f"Σ [cyan]↑{_fmtk(a.tok_in)}[/] [yellow]↓{_fmtk(a.tok_out)}[/] "
                    f"[green]${a.cost:.4f}[/]   [dim](/usage /model /mode /help)[/]")

        def _refresh_status(self):
            self.query_one("#status", Static).update(self._status_text())

        def on_mount(self):
            self.query_one("#prompt", Input).focus()
            if self.session_id:
                self._load_transcript()

        def _log(self):
            return self.query_one("#log", VerticalScroll)

        def _add(self, widget):
            self._log().mount(widget)
            self._log().scroll_end(animate=False)

        # -- load prior transcript for an existing session --
        def _load_transcript(self):
            def go():
                try:
                    r = requests.get(_tok_url(base_url, f"projects/agent/sessions/{self.session_id}",
                                              token, project_id), timeout=30)
                    data = r.json() if r.status_code == 200 else {}
                except requests.RequestException:
                    data = {}
                self.app.call_from_thread(self._render_transcript, data)
            self.run_worker(go, thread=True)

        def _render_transcript(self, data):
            last_goal = ""
            for run in data.get("runs", []):
                goal = (run.get("goal") or "").strip()
                if goal:
                    last_goal = goal
                    self._add(Static(f"[b green]▸ you[/]  {_esc(goal)}", classes="you"))
                for st in run.get("steps", []):
                    self._add(step_widget(st))
                self._acc_usage(run)
            if last_goal:
                self._set_last(last_goal)
            self._refresh_status()

        # -- input handling --
        def on_input_submitted(self, event):
            text = (event.value or "").strip()
            self.query_one("#prompt", Input).value = ""
            if not text:
                return
            if text.startswith("/"):
                self._command(text)
                return
            if self.busy:
                self._add(Static("[yellow]still working on the last turn — Esc to cancel[/]",
                                 classes="status"))
                return
            self._add(Static(f"[b green]▸ you[/]  {_esc(text)}", classes="you"))
            self._set_last(text)
            self._send(text)

        def _command(self, text):
            parts = text.split()
            cmd = parts[0].lower()
            if cmd == "/help":
                self._add(Static(
                    "[b]commands[/]\n"
                    "  /mode \\[plan|manual|auto_edit|full]   set the run mode\n"
                    "  /model                                pick a favorite model (or open the selector)\n"
                    "  /usage                                token usage: context window + spend by model\n"
                    "  /new                                  start a fresh conversation\n"
                    "  /sessions                             back to the conversation list\n"
                    "  /quit                                 exit\n"
                    "  Esc cancels the current turn.", classes="status"))
            elif cmd == "/mode":
                if len(parts) > 1 and parts[1] in MODES:
                    self.app.mode = parts[1]
                    self._refresh_status()
                    self._add(Static(f"[dim]mode → {self.app.mode} ({MODE_HELP[self.app.mode]})[/]",
                                     classes="status"))
                else:
                    self._add(Static("[dim]usage: /mode plan|manual|auto_edit|full[/]", classes="status"))
            elif cmd == "/model":
                self._open_model_picker()
            elif cmd == "/usage":
                self.app.push_screen(UsageModal())
            elif cmd == "/new":
                self.app.open_chat(None)
            elif cmd == "/sessions":
                self.app.push_screen(SessionPicker())
            elif cmd in ("/quit", "/exit"):
                self.app.exit()
            else:
                self._add(Static(f"[dim]unknown command {_esc(cmd)} — /help[/]", classes="status"))

        def _open_model_picker(self):
            def go():
                favs = []
                try:
                    r = requests.get(_tok_url(base_url, "projects/agent/models/favorites",
                                              token, project_id), timeout=15)
                    if r.status_code == 200:
                        favs = (r.json() or {}).get("favorites", [])
                except requests.RequestException:
                    pass
                for f in favs:
                    if isinstance(f, dict) and f.get("id") and f.get("context_length"):
                        self.app.ctx_max_by_model[f["id"]] = f["context_length"]
                self.app.call_from_thread(self._show_picker, favs)
            self.run_worker(go, thread=True)

        def _show_picker(self, favs):
            self._favs = favs

            def done(model):
                if not model:
                    return
                self.app.model = model
                self._add(Static(f"[dim]model → {_esc(model)}[/]", classes="status"))
                # If this model supports reasoning, offer an effort selector next.
                info = next((f for f in (self._favs or [])
                             if isinstance(f, dict) and f.get("id") == model), None)
                if info and info.get("supports_reasoning") and info.get("reasoning_efforts"):
                    def eff_done(effort):
                        self.app.reasoning_effort = effort if effort and effort != "none" else None
                        if self.app.reasoning_effort:
                            self._add(Static(f"[dim]reasoning → {_esc(self.app.reasoning_effort)}[/]",
                                             classes="status"))
                        self._refresh_status()
                    self.app.push_screen(
                        ReasoningPicker(model, info["reasoning_efforts"],
                                        info.get("reasoning_mandatory"), self.app.reasoning_effort),
                        eff_done)
                else:
                    self.app.reasoning_effort = None   # non-reasoning model → clear
                self._refresh_status()
            self.app.push_screen(ModelPicker(favs, self.app.model), done)

        def action_cancel(self):
            if self.busy and self.run_id:
                rid = self.run_id

                def go():
                    try:
                        requests.post(_tok_url(base_url, f"projects/agent/runs/{rid}/cancel",
                                               token, project_id), timeout=15)
                    except requests.RequestException:
                        pass
                self.run_worker(go, thread=True)
                self._add(Static("[yellow]cancelling…[/]", classes="status"))

        def action_sessions(self):
            self.app.push_screen(SessionPicker())

        # -- send a message: create run, then poll-stream it --
        def _send(self, goal):
            self.busy = True

            def go():
                try:
                    body = {"goal": goal, "mode": self.app.mode}
                    if self.session_id:
                        body["session_id"] = self.session_id
                    # Send a picked model (a real provider/model id) — the server
                    # honors it only if it's in the user's favorites.
                    if self.app.model and "/" in self.app.model:
                        body["model"] = self.app.model
                    if self.app.reasoning_effort:
                        body["reasoning_effort"] = self.app.reasoning_effort
                    r = requests.post(_tok_url(base_url, "projects/agent/runs", token, project_id),
                                      json=body, timeout=30)
                    if r.status_code not in (200, 201):
                        self.app.call_from_thread(self._turn_error, f"create failed: {r.text[:200]}")
                        return
                    d = r.json()
                    rid = d.get("run_id")
                    self.app.call_from_thread(self._turn_started, rid, d.get("session_id"), d.get("model"))
                except requests.RequestException as e:
                    self.app.call_from_thread(self._turn_error, f"could not reach Viclix: {e}")
                    return

                since = -1
                while True:
                    try:
                        pr = requests.get(_tok_url(base_url, f"projects/agent/runs/{rid}",
                                                   token, project_id) + f"&since={since}", timeout=20)
                    except requests.RequestException:
                        time.sleep(1.5)
                        continue
                    if pr.status_code != 200:
                        time.sleep(1.5)
                        continue
                    data = pr.json()
                    for st in data.get("steps", []):
                        since = max(since, st.get("idx", since))
                        self.app.call_from_thread(self._add, step_widget(st))
                    if data.get("status") in TERMINAL:
                        self.app.call_from_thread(self._turn_done, data)
                        return
                    time.sleep(1.2)
            self.run_worker(go, thread=True)

        def _turn_started(self, run_id, session_id, model):
            self.run_id = run_id
            if session_id:
                self.session_id = session_id
            if model and "/" in model:   # a real provider/model id (not "user-default")
                self.app.model = model
            self._add(Static("[dim]· working…[/]", classes="status"))
            self._refresh_status()

        def _acc_usage(self, run):
            """Fold one run's tokens/cost into the session totals + per-model table."""
            a = self.app
            model = run.get("model") or "default"
            i = run.get("input_tokens") or 0
            o = run.get("output_tokens") or 0
            try:
                c = float(run.get("cost") or 0)
            except (TypeError, ValueError):
                c = 0.0
            u = a.usage_by_model.setdefault(model, {"msgs": 0, "in": 0, "out": 0, "cost": 0.0})
            u["msgs"] += 1
            u["in"] += i
            u["out"] += o
            u["cost"] += c
            a.tok_in += i
            a.tok_out += o
            a.cost += c
            if i:
                a.ctx_used = i           # latest run's input ≈ current context size
            if model != "default":
                a.model = model

        def _turn_done(self, data):
            self.busy = False
            self.run_id = None
            self._acc_usage(data)
            it = data.get("input_tokens") or 0
            ot = data.get("output_tokens") or 0
            model = data.get("model") or self.app.model
            try:
                cost = float(data.get("cost") or 0)
            except (TypeError, ValueError):
                cost = 0.0
            status = data.get("status")
            if status not in ("done", "chat"):
                tag = {"error": "[red]", "cancelled": "[yellow]"}.get(status, "[dim]")
                self._add(Static(f"{tag}· {_esc(status)}[/]", classes="status"))
            costtxt = f" · [green]${cost:.4f}[/]" if cost else ""
            self._add(Static(f"[b]Total[/] [cyan]{_fmtk(it)} in[/] · [yellow]{_fmtk(ot)} out[/]"
                             f"{costtxt}   [dim]{_esc(model)}[/]", classes="total"))
            self._refresh_status()
            self.query_one("#prompt", Input).focus()

        def _turn_error(self, msg):
            self.busy = False
            self.run_id = None
            self._add(Static(f"[b red]✗[/] {_esc(msg)}", classes="error"))

    # ── the app ────────────────────────────────────────────────────────────────
    class ViclixChatApp(App):
        CSS = """
        Screen { layout: vertical; }
        #lastmsg { dock: top; height: auto; max-height: 4; padding: 0 1; background: $boost; border-bottom: solid $primary; }
        #log { height: 1fr; padding: 0 1; }
        #prompt { dock: bottom; }
        #status { dock: bottom; height: 1; color: $text-muted; padding: 0 1; }
        .you { margin: 1 0 0 0; }
        .reply { margin: 0 0 0 2; }
        .think { margin: 0 0 0 2; }
        .status { margin: 0 0 0 2; }
        .error { margin: 0 0 0 2; }
        .ask { margin: 1 0 0 2; }
        .tool { margin: 0 0 0 2; }
        .total { margin: 0 0 1 0; }
        .hint { padding: 1; color: $text-muted; }
        ModelPicker { align: center middle; }
        #picker { width: 84; max-width: 90%; height: auto; max-height: 80%;
                  background: $panel; border: thick $primary; padding: 1 2; }
        #picker ListView { height: auto; max-height: 22; margin-top: 1; }
        UsageModal { align: center middle; }
        #usagebox { width: 74; max-width: 90%; height: auto; background: $panel;
                    border: thick $primary; padding: 1 2; }
        ReasoningPicker { align: center middle; }
        #reasonbox { width: 54; max-width: 90%; height: auto; background: $panel;
                     border: thick $primary; padding: 1 2; }
        #reasonbox ListView { height: auto; max-height: 12; margin-top: 1; }
        """
        TITLE = "viclix agents"

        def __init__(self):
            super().__init__()
            self.mode = "plan"
            self.model = "account default"
            self.reasoning_effort = None      # set via /model when a reasoning model is picked
            self.cost = 0.0
            self.tok_in = 0
            self.tok_out = 0
            self.ctx_used = 0                 # latest run's input tokens ≈ context size
            self.usage_by_model = {}          # model -> {msgs, in, out, cost}
            self.ctx_max_by_model = {}        # model -> context_length (from favorites)

        def on_mount(self):
            self.push_screen(SessionPicker())

        def open_chat(self, session_id):
            # Replace the whole stack with a fresh chat screen.
            self.push_screen(ChatScreen(session_id))

    return ViclixChatApp()
