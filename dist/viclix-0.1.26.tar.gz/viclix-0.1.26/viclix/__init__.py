__version__ = "0.1.26"

from .cli import main

__all__ = ["main", "__version__"]
